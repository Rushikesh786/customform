<?php
namespace Bliss\Customform\Block;
use Magento\Framework\View\Element\Template;


class Customform extends \Magento\Framework\View\Element\Template
{
	

	private $_customform;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Bliss\Customform\Model\Customform $customform,
        \Magento\Framework\App\ResourceConnection $resource,
        array $data = []
    ) {
        $this->_customform = $customform;
        $this->_resource = $resource;

        parent::__construct(
            $context,
            $data
        );
    }

    public function getCustomforms()
    {
        $collection = $this->_customform->getCollection();
        return $collection;
    }

    public function getHelloWorldTxt()
    {
        return 'Hello world!';
    }
    public function getCustomformTxt()
    {
        return 'Custom Form!';
    }  
 
}