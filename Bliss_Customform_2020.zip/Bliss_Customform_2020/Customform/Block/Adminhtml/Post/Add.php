<?php
namespace Bliss\Customform\Block\Adminhtml\Post;

class Add extends \Magento\Backend\Block\Widget\Form\Container {
   
    protected $_coreRegistry = null;
  
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context, 
        \Magento\Framework\Registry $registry, 
        array $data = []) 
    {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }
    
    protected function _construct() {
        //$this->_objectId = 'row_id';
        $this->_objectId = 'bliss_customform_id'; // New Changed.......................
        $this->_blockGroup = 'Bliss_Customform';
        $this->_controller = 'adminhtml_post';
        parent::_construct();
        if ($this->_isAllowedAction('Bliss_Customform::add')) {
            $this->buttonList->update('save', 'label', __('Save'));
        } else {
            $this->buttonList->remove('save');
        }
        $this->buttonList->remove('reset');
    }
   
    public function getHeaderText() {
        return __('Add Post');
    }
  
    protected function _isAllowedAction($resourceId) {
        return $this->_authorization->isAllowed($resourceId);
    }
   
    public function getFormActionUrl() {
        if ($this->hasFormActionUrl()) {
            return $this->getData('form_action_url');
        }
        return $this->getUrl('*/*/save');
    }
}