<?php
namespace Bliss\Customform\Block\Adminhtml\Post\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    protected $_systemStore;

    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig,
        array $data = []
    ) {
        
        $this->_wysiwygConfig = $wysiwygConfig;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    protected function _prepareForm()
    {
        //$dateFormat = $this->_localeDate->getDateFormat(\IntlDateFormatter::SHORT);
        $model = $this->_coreRegistry->registry('customform');
        
        $form = $this->_formFactory->create(
            ['data' => [
                            'id' => 'edit_form', 
                            'enctype' => 'multipart/form-data', 
                            'action' => $this->getData('action'), 
                            'method' => 'post'
                        ]
            ]
        );

        $form->setHtmlIdPrefix('post_');
        if ($model->getBlissCustomformId()) {
            $fieldset = $form->addFieldset(
                'base_fieldset', 
                ['legend' => __('Edit Post Data'), 'class' => 'fieldset-wide']
            );
            $fieldset->addField('bliss_customform_id', 'hidden', ['name' => 'bliss_customform_id']);
        } else {
            $fieldset = $form->addFieldset(
                'base_fieldset', 
                ['legend' => __('Add Post Data'), 'class' => 'fieldset-wide']
            );
        }

        /*$fieldset->addField(
            'bliss_customform_id', `
            'text', 
            [
                'name' => 'bliss_customform_id', 
                'label' => __('Customform Id'), 
                'id' => 'bliss_customform_id', 
                'title' => __('Customform Id'),                 
                'disabled' => false, 
            ]
        );*/
        $fieldset->addField(
            'fname', 
            'text', 
            [
                'name' => 'fname', 
                'label' => __('First Name'), 
                'id' => 'fname', 
                'title' => __('First Name'), 
                'class' => 'required-entry', 
                'required' => true, 
                'disabled' => false, 
            ]
        );
        $fieldset->addField(
            'lname', 
            'text', 
            [
                'name' => 'lname', 
                'label' => __('Last Name'), 
                'id' => 'lname', 
                'title' => __('Last Name'), 
                'class' => 'required-entry', 
                'required' => true, 
                'disabled' => false, 
            ]
        );

        $wysiwygConfig = $this->_wysiwygConfig->getConfig(['tab_id' => $this->getTabId()]);
        $fieldset->addField(
            'address',
            'editor',
            [
                'name' => 'address',
                'label' => __('Address'),
                'id' => 'lname',
                'style' => 'height:36em;',
                'required' => true,
                'config' => $wysiwygConfig,
                'disabled' => false,
            ]
        );
        $fieldset->addField(
            'email', 
            'text', 
            [
                'name' => 'email', 
                'label' => __('Email'), 
                'id' => 'email', 
                'title' => __('Email'), 
                'class' => 'required-entry', 
                'required' => true, 
                'disabled' => false, 
            ]
        );
        $fieldset->addField(
            'phonenumber', 
            'text', 
            [
                'name' => 'phonenumber', 
                'label' => __('Phone Number'), 
                'id' => 'phonenumber', 
                'title' => __('Phone Number'), 
                'class' => 'required-entry', 
                'required' => true, 
                'disabled' => false, 
            ]
        );
        
        //$fieldset->addType('image', '\Bliss\Customform\Block\Adminhtml\Form\Edit\Tab\ImageRenderer');
       $fieldset->addField(
            'image',
            'image',
            [
                'name' => 'image',
                'title' => __('Image'),
                'label' => __('Image'),
                'id' => 'image', 
                'note' => 'Allow image type: jpg, jpeg, gif, png',
            ]
        );
        
        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
