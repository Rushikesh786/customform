<?php
namespace Bliss\Customform\Controller\Adminhtml\Post;
use Magento\Framework\Controller\ResultFactory;
class Add extends \Magento\Backend\App\Action 
{        
        private $coreRegistry;
        protected $_postFactory;
  
        public function __construct(
            \Magento\Backend\App\Action\Context $context, 
            \Magento\Framework\Registry $coreRegistry, 
            \Bliss\Customform\Model\CustomformFactory $customformFactory)      
        {
                parent::__construct($context);
                $this->coreRegistry     = $coreRegistry;
                $this->_customformFactory = $customformFactory;
            
        }
        protected function _isAllowed()      
        {
                return $this->_authorization->isAllowed('Bliss_Customform::add');
        }        
        public function execute(){
            $rowId = (int)$this->getRequest()->getParam('bliss_customform_id');
            $rowData = $this->_objectManager->create('Bliss\Customform\Model\Customform');

            if($rowId) {
                $rowData = $this->_customformFactory->create()->load($rowId);
                if(!$rowData->getId()) {
                    $this->messageManager->addError(__('post data no longer exist.'));
                    $this->_redirect('bliss_customform/post');
                    return;                    
                }                
            }
            $this->coreRegistry->register('customform', $rowData);
            $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
            $title       = $rowId ? __('Edit Post Data ') : __('Add Post Data');
            $resultPage->getConfig()->getTitle()->prepend($title);
            return $resultPage;
        }
        
}