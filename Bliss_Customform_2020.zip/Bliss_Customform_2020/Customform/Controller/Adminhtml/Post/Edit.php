<?php
namespace Bliss\Customform\Controller\Adminhtml\Post;

use Magento\Backend\App\Action;

class Edit extends \Magento\Backend\App\Action
{
    protected $_coreRegistry = null;
    protected $resultPageFactory;

    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
        parent::__construct($context);
    }
 
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Bliss_Customform::save');
    }

    protected function _initAction()
    {      
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Bliss_Customform::customform_post')
            ->addBreadcrumb(__('Customform'), __('Customform'))
            ->addBreadcrumb(__('Manage All Customform'), __('Manage All Customform'));
        return $resultPage;
    }
    public function execute()
    {
        //echo("Hello......");
        // 1. Get ID and create model
        $id = $this->getRequest()->getParam('bliss_customform_id');
        //print_r($id);die();
        $model = $this->_objectManager->create('Bliss\Customform\Model\Customform');

        // 2. Initial checking
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This post no longer exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();
                return $resultRedirect->setPath('*/*/');
            }
        }

        $this->_coreRegistry->register('customform_post', $model);     
        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit Customform') : __('Add Customform'),
            $id ? __('Edit Customform') : __('Add Customform')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('Customform'));
        $resultPage->getConfig()->getTitle()
            ->prepend($model->getId() ? $model->getTitle() : __('Add Customform'));

        return $resultPage;
    }
}
