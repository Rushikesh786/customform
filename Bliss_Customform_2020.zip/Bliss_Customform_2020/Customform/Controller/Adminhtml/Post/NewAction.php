<?php
namespace Bliss\Customform\Controller\Adminhtml\Post;
use Magento\Backend\App\Action;

class NewAction extends \Magento\Backend\App\Action
{
    protected $resultForwardFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Backend\Model\View\Result\ForwardFactory $resultForwardFactory
    ) {
        $this->resultForwardFactory = $resultForwardFactory;
        parent::__construct($context);
    }
   
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Bliss_Customform::save');
    }

    public function execute()
    {   
        //echo "Hello.....";die();        
        $resultForward = $this->resultForwardFactory->create();
        return $resultForward->forward('add');
    }
}
