<?php
namespace Bliss\Customform\Controller\Adminhtml\Post;

use Magento\Framework\App\Action\Context;
use Bliss\Customform\Model\CustomformFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\MediaStorage\Model\File\UploaderFactory;
use Magento\Framework\Image\AdapterFactory;
use Magento\Framework\Filesystem;

class Save extends \Magento\Backend\App\Action
{
    protected $_customformFactory;
    protected $uploaderFactory;
    protected $adapterFactory;
    protected $filesystem;

    public function __construct(
        \Magento\Backend\App\Action\Context $context, 
        UploaderFactory $uploaderFactory,
        AdapterFactory $adapterFactory,
        Filesystem $filesystem,
        \Bliss\Customform\Model\CustomformFactory $customformFactory
    )
    {
        $this->_customformFactory = $customformFactory;
        $this->uploaderFactory = $uploaderFactory;
        $this->adapterFactory = $adapterFactory;
        $this->filesystem = $filesystem;
        parent::__construct($context);
    }    
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        //echo '<pre>'; print_r($data);die();
        if (!$data) {
            $this->_redirect('bliss_customform/post/add');
            return;
        }    
        if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != ''){                    
        try { 
                $uploaderFactory = $this->uploaderFactory->create(['fileId' => 'image']);
                $uploaderFactory->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
                $imageAdapter = $this->adapterFactory->create();
                $uploaderFactory->addValidateCallback('custom_image_upload',$imageAdapter,'validateUploadFile');
                $uploaderFactory->setAllowRenameFiles(true);
                $uploaderFactory->setFilesDispersion(true);
                $mediaDirectory = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA);
                $destinationPath = $mediaDirectory->getAbsolutePath('bliss/customform');
                $result = $uploaderFactory->save($destinationPath);
                if (!$result) {
                    throw new LocalizedException(
                        __('File cannot be saved to path: $1', $destinationPath)
                    );
                }
                $imagePath = 'bliss/customform'.$result['file'];
                $data['image'] = $imagePath;

                                              
                $rowData = $this->_customformFactory->create();
                $rowData->setData($data);
                if (isset($data['id'])) {
                    $rowData->setEntityId($data['id']);
                }
                $rowData->save();
                $this->messageManager->addSuccess(__('Post has been successfully saved.'));
            }
        catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
        }
        $this->_redirect('bliss_customform/post');
    }        
    }    
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Bliss_Customform::save');
    }
}