<?php
namespace Bliss\Customform\Model\ResourceModel;
class Customform extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    
    protected function _construct()
    {
        $this->_init('bliss_customform', 'bliss_customform_id');
    }
}