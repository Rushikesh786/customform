<?php
namespace Bliss\Customform\Model\ResourceModel\Customform;
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    
    protected $_idFieldName = 'bliss_customform_id';

    protected function _construct()
    {
        $this->_init(
            'Bliss\Customform\Model\Customform',
            'Bliss\Customform\Model\ResourceModel\Customform'
        );
    }
}