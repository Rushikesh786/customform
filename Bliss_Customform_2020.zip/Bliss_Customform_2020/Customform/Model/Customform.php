<?php
namespace Bliss\Customform\Model;
use Magento\Framework\Model\AbstractModel;
class Customform extends AbstractModel
{
   
    protected function _construct()
    {
        $this->_init('Bliss\Customform\Model\ResourceModel\Customform');
    }
}